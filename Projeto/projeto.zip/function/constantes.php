<?php
    
define('ERRO_CAIXA_VAZIA', "<span class='msgErro'>Não é possivel calcular sem preencher todos os campos </span>");

//forma 02 de criar uma constante
const ERRO_DADOS_NAO_NUMERICOS = "<span class='msgErro'>Não é possivel realizar calculos com valores não numericos</span>";

const ERRO_DIVISAO_ZERO = "<span class='msgErro'> Impossivel realizar uma divisão por zero! </span>";

const ERRO_MAIOR = "Primeiro valor maior que o segundo:";



?>