<hmtl>
    <head>
        <title>Menu Drop</title>
        <meta charset="utf-8">
        <link rel="stylesheet"
              type="text/css"
              href="CSS/style.css">
    </head>
    <body>
        <div>
            <div class="hamburger">
                <span class="ham"></span>
                <span class="ham"></span>
                <span class="ham"></span>
                
                <div class="hamburger-content">
                    <ul>
                        <li>
                            <a href="media.php">
                            Média
                            </a>
                        </li>
                        <li>
                            <a href="calculadora.php">
                                Calculadora
                            </a>
                            </li>
                        <li>
                            <a href="tabuada.php">
                            Tabuada
                            </a>
                            </li>
                        <li>
                            <a href="parimpar.php">
                            Pares e Impares
                            </a>
                        </li>
                    </ul>
                
                </div>
            </div>

         </div>
    </body>
</hmtl>