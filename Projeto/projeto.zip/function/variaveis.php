<?php
//Variaveis Média
    $media = null;
    $nota1 = null;
    $nota2 = null;
    $nota3 = null;
    $nota4 = null;

//Variaveis Calculadora
    $resultado = (double) 0;
    $valor1 = (double) 0;
    $valor2 = (double) 0;
    $operacao = (string) null;

//Variaveis Tabuada
    $tabuada = (double) 0;
    $contador = (double) 0;
    $count=1;

//Variaveis Impares e Pares
    $impares = (string)null;
    $pares = (string)null;
    $imparesQ = (int)0;
    $paresQ = (int)0;

?>